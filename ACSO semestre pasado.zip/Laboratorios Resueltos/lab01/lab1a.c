#include <stdlib.h>
#include <stdio.h>

int maximocmd(int a, int b);

void imprimir(int numeros [], int mcd);

int main()
{
    int numeros[5], i, mcd, numero; 
    for (i = 0; i <= 4; i++) {
        scanf("%i", &numero);
        numeros[i] = numero;
        if (i == 0){
            mcd = numero;
        }
        else{
            mcd = maximocmd(numero,mcd);
        }
    }
    imprimir (numeros, mcd);
    return 0;
}

int maximocmd(int numero, int mcd){
    int residuo;
    do{
        residuo = mcd % numero;
        if (residuo != 0){
            mcd = numero;
            numero = residuo;
        }
        else {
            mcd = numero;
        }
    }while (residuo != 0);
    return mcd;
}

void imprimir(int numeros [], int mcd){
    int i, suma, resultado;
    suma = 0;
    printf("%i \n",mcd);
    for (i = 0; i <= 4; i++){
        resultado = (numeros[i] / mcd);
        suma = suma + resultado;
        printf("%i \n", resultado);
    }
    printf("%i \n", suma);
}