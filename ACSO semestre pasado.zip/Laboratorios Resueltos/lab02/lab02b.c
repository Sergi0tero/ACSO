#include <stdio.h>
float productoPunto(float arrayUno[],float arrayDos[],int numero){
    float resultado;
    int i;
        for (i = 0; i < numero; i ++){
            resultado += arrayUno[i] * arrayDos[i];
        }
    return resultado;
}

void imprimir(float resultados[], int numero){
    int i;
    for (i = 0; i < numero; i ++){
        if (resultados[i] == 0){
            i = numero;
        }
        else{
            printf("%f \n", resultados[i]); 
        }
    }
}

int main()
{
    int i,j, numero, numeros; 
    float arrayUno[1980], arrayDos[1980],numeroLeer,resultado[1980]; 
    scanf("%i", &numero);
    for (i = 0; i < numero; i++) {
        scanf("%i", &numeros);
        for (j = 0; j < numeros*2;j++){
            if (j < numeros){
                scanf("%f", &numeroLeer);
                arrayUno[j] = numeroLeer;  
            }
            else{
                scanf("%f", &numeroLeer);
                arrayDos[j-numeros] = numeroLeer; 
            }
        }
        resultado[i] = productoPunto(arrayUno,arrayDos,numeros);
    }
    imprimir(resultado,numero);
    return 0;
}