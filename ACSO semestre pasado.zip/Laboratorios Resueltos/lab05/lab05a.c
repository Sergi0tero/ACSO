#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int descubrirCantidad(char *numero,int base){
    int i,j,x,cont,contDos, valor = 0,valores[26] = {10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26 ,27, 28, 29, 30, 31, 32,33, 34,35};
    char  letras[26] = {'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z'};
    x = strlen(numero);
    cont = 0;
    for (i = 0;i < x; i ++){
        contDos = 24;
        for(j = 0 ; j <24 ; j ++){
            if (numero[i] == letras[j]) {
                cont = cont + 1;
                valor = valor + (valores[j] * pow(base, x-cont));
            }
            else{
               contDos = contDos - 1;
            }
            if (contDos == 0){
                int num = numero[i] - '0';
                cont = cont + 1;
                valor = valor + (num * pow(base, x-cont));
            }
        }
    }
    return valor;
}

void imprime_digito_en_base(int digito) {
    if (digito < 10)
        printf("%d", digito);
    else {
        char digito_transformado = digito - 10 + 'A';
        printf("%c", digito_transformado);
    }
} 

int encuentra_mayor_potencia_menor_o_igual_a_numero(int numero, int base) {
    int factor = 1;
    while (factor <= numero)
        factor *= base;
    return factor/base;
} 

void imprime_en_otra_base(int numero, int base) {
    int factor = encuentra_mayor_potencia_menor_o_igual_a_numero(numero, base);    
    do {
        int digito = numero / factor;
        imprime_digito_en_base(digito);
        numero %= factor;
        factor /= base;
    } while (factor > 0);
} 

int main() {
    int i,j,suma,base,cantidadUno,cantidadDos;
    char numeroUno[4000],numeroDos[4000];
    scanf("%i", &suma);
    int resultado[suma];
    for (i = 0;i < suma; i ++){
        scanf("%s", &numeroUno);
        scanf("%s", &numeroDos);
        cantidadUno = descubrirCantidad(numeroUno,base);
        cantidadDos = descubrirCantidad(numeroDos,base);
        printf("\n%d",cantidadUno);
        printf("\n%d",cantidadDos);
        imprime_en_otra_base(cantidadUno + cantidadDos, base);
    }
    return 0;
} 