clear
grep -i "$1" $2