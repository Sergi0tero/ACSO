clear

echo El numero de lineas dele archivo /etc/profile es:
wc -l /etc/profie
